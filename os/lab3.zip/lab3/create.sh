gcc test.c -o ./folder/test1;
gcc test.c -o ./folder/test2;
gcc test.c -o ./folder/test3;
