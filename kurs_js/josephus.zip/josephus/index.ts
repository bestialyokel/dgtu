
import List from "./deps/list"
import Task from "./deps/task"


let task = new Task(41, 3, true);

let result = task.find_last();


console.log(result);